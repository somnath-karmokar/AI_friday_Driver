
import pandas as pd
import numpy as np

def generate():
    np.random.seed(22)

    drivers = pd.DataFrame({
        "driver_id":[f"D{i:03}" for i in range(60)],
        "hours_worked_week":np.random.randint(20,65,60),
        "earnings_week":np.random.randint(900,3200,60),
        "rest_hours":np.random.randint(6,12,60),
        "fatigue_score":np.round(np.random.rand(60)*10,2)
    })

    shifts = pd.DataFrame({
        "shift_id":[f"S{i:03}" for i in range(40)],
        "shift_hours":np.random.choice([6,8,10],40),
        "route":"Route_"+np.random.randint(1,15,40).astype(str)
    })

    vehicles = pd.DataFrame({
        "vehicle_id":[f"V{i:03}" for i in range(20)],
        "idle_minutes":np.random.randint(20,200,20),
        "fuel_used_liters":np.round(np.random.rand(20)*50,2)
    })

    drivers.to_csv("../data/drivers.csv",index=False)
    shifts.to_csv("../data/shifts.csv",index=False)
    vehicles.to_csv("../data/vehicle_logs.csv",index=False)

if __name__ == "__main__":
    generate()
