
import pandas as pd

def fairness_metrics(schedule):

    workload = schedule.groupby("driver_id")["shift_hours"].sum()

    return {
        "drivers_used": int(workload.count()),
        "max_hours": float(workload.max()),
        "min_hours": float(workload.min()),
        "std_dev_hours": float(workload.std())
    }

def fatigue_metrics(schedule):

    return {
        "avg_fatigue": float(schedule["fatigue_score"].mean()),
        "max_fatigue": float(schedule["fatigue_score"].max())
    }
