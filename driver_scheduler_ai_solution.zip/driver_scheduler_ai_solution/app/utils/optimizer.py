
import pandas as pd

def generate_schedule(drivers, shifts):

    drivers = drivers.copy()

    drivers["fairness_score"] = drivers["earnings_week"] / drivers["hours_worked_week"]
    drivers["fatigue_penalty"] = drivers["fatigue_score"] * 0.6 + (10 - drivers["rest_hours"]) * 0.4

    drivers = drivers.sort_values(["fatigue_penalty","fairness_score"])

    schedule = []
    i=0

    for _,shift in shifts.iterrows():
        driver = drivers.iloc[i % len(drivers)]

        schedule.append({
            "shift_id":shift["shift_id"],
            "route":shift["route"],
            "driver_id":driver["driver_id"],
            "shift_hours":shift["shift_hours"],
            "fatigue_score":driver["fatigue_score"],
            "fairness_score":driver["fairness_score"]
        })

        i+=1

    return pd.DataFrame(schedule)
