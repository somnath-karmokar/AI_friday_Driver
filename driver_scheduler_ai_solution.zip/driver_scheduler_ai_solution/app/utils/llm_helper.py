
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage
from utils.config import load_config

def ask_llm(prompt):

    cfg = load_config()

    if not cfg:
        return "LLM not configured."

    llm = ChatOpenAI(
        model=cfg.get("model","gpt-4o-mini"),
        api_key=cfg.get("api_key")
    )

    response = llm.invoke([HumanMessage(content=prompt)])

    return response.content
