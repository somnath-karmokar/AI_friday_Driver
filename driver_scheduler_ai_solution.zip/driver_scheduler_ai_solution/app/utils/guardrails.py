
import json, os

CONFIG_FILE = "guardrail_config.json"

DEFAULT = {
    "block_hallucination": True,
    "require_context": True,
    "max_fatigue_allowed": 8
}

def load_guardrails():
    if not os.path.exists(CONFIG_FILE):
        return DEFAULT
    with open(CONFIG_FILE) as f:
        return json.load(f)

def save_guardrails(cfg):
    with open(CONFIG_FILE,"w") as f:
        json.dump(cfg,f,indent=2)
