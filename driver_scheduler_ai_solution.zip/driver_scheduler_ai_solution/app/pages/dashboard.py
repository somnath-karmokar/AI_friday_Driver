
import streamlit as st
import pandas as pd
from pathlib import Path

DATA = Path(__file__).resolve().parents[2] / "data"

drivers = pd.read_csv(DATA/"drivers.csv")
vehicles = pd.read_csv(DATA/"vehicle_logs.csv")

st.title("📊 Operations Dashboard")

st.dataframe(drivers)

st.subheader("Vehicle Idle & Fuel Usage")
st.dataframe(vehicles)

st.bar_chart(vehicles["idle_minutes"])
