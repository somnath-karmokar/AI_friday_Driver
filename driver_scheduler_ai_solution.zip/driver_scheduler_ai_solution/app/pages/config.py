
import streamlit as st
from utils.config import load_config, save_config

st.title("⚙ LLM Configuration")

cfg = load_config()

provider = st.selectbox("Provider",["OpenAI","Azure OpenAI"])
api_key = st.text_input("API Token",type="password")
model = st.text_input("Model Name","gpt-4o-mini")

if st.button("Save"):
    save_config({
        "provider":provider,
        "api_key":api_key,
        "model":model
    })

    st.success("Configuration saved")
