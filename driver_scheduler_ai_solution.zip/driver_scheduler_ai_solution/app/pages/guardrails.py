
import streamlit as st
from utils.guardrails import load_guardrails, save_guardrails

st.title("🛡 LLM Guardrails")

cfg = load_guardrails()

block = st.checkbox("Block hallucination",cfg["block_hallucination"])
context = st.checkbox("Require grounded context",cfg["require_context"])
fatigue = st.slider("Max fatigue allowed",1,10,cfg["max_fatigue_allowed"])

if st.button("Save Guardrails"):

    save_guardrails({
        "block_hallucination":block,
        "require_context":context,
        "max_fatigue_allowed":fatigue
    })

    st.success("Guardrails saved")
