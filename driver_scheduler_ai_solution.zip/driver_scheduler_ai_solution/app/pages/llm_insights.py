
import streamlit as st
from utils.llm_helper import ask_llm

st.title("🤖 LLM Scheduling Insights")

question = st.text_area("Ask about the schedule, fairness or fatigue risks")

if st.button("Ask LLM"):
    response = ask_llm(question)
    st.write(response)
