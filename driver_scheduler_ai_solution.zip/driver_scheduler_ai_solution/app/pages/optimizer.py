
import streamlit as st
import pandas as pd
from pathlib import Path
from utils.optimizer import generate_schedule

DATA = Path(__file__).resolve().parents[2] / "data"

drivers = pd.read_csv(DATA/"drivers.csv")
shifts = pd.read_csv(DATA/"shifts.csv")

st.title("🧠 Scheduling Optimizer")

if st.button("Generate Schedule"):
    schedule = generate_schedule(drivers,shifts)

    st.dataframe(schedule)

    schedule.to_csv(DATA/"generated_schedule.csv",index=False)
