
import streamlit as st
import pandas as pd
from pathlib import Path
from utils.audit import fairness_metrics, fatigue_metrics

DATA = Path(__file__).resolve().parents[2] / "data"

st.title("⚖ Fairness & Fatigue Audit")

file = DATA/"generated_schedule.csv"

if file.exists():

    schedule = pd.read_csv(file)

    st.json(fairness_metrics(schedule))
    st.json(fatigue_metrics(schedule))

    st.bar_chart(schedule.groupby("driver_id")["shift_hours"].sum())

else:
    st.warning("Generate schedule first.")
