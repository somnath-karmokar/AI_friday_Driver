
import streamlit as st

st.set_page_config(page_title="AI Driver Scheduler",layout="wide")

st.title("🚚 AI Fair & Fatigue-Aware Driver Scheduling Optimizer")

st.markdown("""
Features:

⚖ Fair scheduling  
😴 Fatigue risk control  
⛽ Vehicle idle analytics  
📊 Fairness audits  
🤖 LLM assistant powered by LangChain  
🛡 Guardrail controls
""")

st.info("Navigate using sidebar.")
