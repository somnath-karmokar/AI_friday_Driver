# AI Driver Scheduling Optimizer (LangChain + Guardrails)

This application demonstrates an AI-based driver scheduling optimizer
using:

-   fairness constraints
-   fatigue risk modelling
-   vehicle idle monitoring
-   LangChain LLM assistant
-   configurable guardrails

------------------------------------------------------------------------

# Features

-   Fair driver scheduling
-   Fatigue risk modelling
-   Vehicle idle analytics
-   Schedule visualization
-   LangChain LLM assistant
-   LLM guardrail configuration
-   Synthetic datasets

------------------------------------------------------------------------

# Pages

Dashboard Optimizer Audit LLM Insights LLM Config Guardrails

------------------------------------------------------------------------

# Run

pip install -r requirements.txt

streamlit run app/main.py

------------------------------------------------------------------------

# Synthetic Data

Located in /data folder

drivers.csv shifts.csv vehicle_logs.csv

------------------------------------------------------------------------

# Regenerate Data

python scripts/generate_synthetic_data.py
